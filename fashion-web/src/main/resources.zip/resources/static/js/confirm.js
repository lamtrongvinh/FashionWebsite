let btn_check_confirm = document.getElementById("btn_confirm_order");
btn_check_confirm.onclick = function clickConfirm() {
    let btn_confirm = document.getElementById("");
}