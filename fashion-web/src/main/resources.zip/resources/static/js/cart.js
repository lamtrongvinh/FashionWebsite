$(document).ready(function() {
    $(".increment-btn").click(function() {
        var productId = $(this).attr("data-product-id");
        var quantity = parseInt($("#quantity-" + productId).text());
        $.ajax({
            type: "GET",
            url: "/product/" + productId + "/increment",
            success: function(data) {
                $("#quantity-" + productId).text(data.quantity);
                $("#total-" + productId).text(data.total);
                var total = 0;
                $(".total").each(function() {
                    total += parseFloat($(this).text());
                });
                $("#grand-total").text(total.toFixed(2));
                location.reload();
            }
        });
    });
});

$(document).ready(function() {
    $(".decrement-btn").click(function() {
        var productId = $(this).attr("data-product-id");
        var quantity = parseInt($("#quantity-" + productId).text());
        $.ajax({
            type: "GET",
            url: "/product/" + productId + "/decrement",
            success: function(data) {
                $("#quantity-" + productId).text(data.quantity);
                $("#total-" + productId).text(data.total);
                var total = 0;
                $(".total").each(function() {
                    total += parseFloat($(this).text());
                });
                $("#grand-total").text(total.toFixed(2));
                location.reload();
            }
        });
    });
});

$(document).ready(function() {
    $(".delete-product").click(function() {
        var productId = $(this).attr("data-product-id");
        $.ajax({
            type: "GET",
            url: "/auth/checkout/delete/" + productId,
            success: function(data) {
                location.reload();
            }
        });
    });
});