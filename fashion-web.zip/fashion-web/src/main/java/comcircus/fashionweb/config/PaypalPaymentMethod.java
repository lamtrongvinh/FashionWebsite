package comcircus.fashionweb.config;

public enum PaypalPaymentMethod {
    credit_card, paypal
}
