package comcircus.fashionweb.exception;

public class ForbiddenException {
    
}
