package comcircus.fashionweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FashionWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(FashionWebApplication.class, args);
	}
}
