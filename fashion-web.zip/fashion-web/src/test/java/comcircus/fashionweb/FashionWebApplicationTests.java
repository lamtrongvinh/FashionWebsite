package comcircus.fashionweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FashionWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
